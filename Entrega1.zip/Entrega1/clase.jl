import Pkg
Mt = 5.972e24 #kg tierra
Ml = 7.349e22 #Kg luna
Ms = 1.989e30 #Kg sol
G = 6.67408e-11 #Cte
#Condiciones iniciales

x0 = -2043910.420340
y0 = 6494158.534729
z0 = 1921965.947022

xp0 = 923.437757
yp0 = 2416.142920
zp0 = -7144.105929


z0 = [x0, y0, z0, xp0, yp0, zp0]

dt = 0.1 #s
tmax = 100

function zpunto(t, z)
    x = z[1:3]
    xp = z[4:6]
    #Calculo Fg
    r = sqrt(x'*x)
    rnorm = x/r
    Fg = G*Mt/r^2 * rnorm
    #Calculo Fgluna
    l = [384400000.,0.,0.]
    xl = x-l
    rl = sqrt(xl'*xl)
    rlnorm = x/rl
    Fluna = G*Ml/rl^2*rlnorm
    #s
    #Calculo Fgsol
    s = [150000000000.,0.,0.]
    xs = x-s
    rs = sqrt(xs'*xs)
    rsnorm = x/rs
    Fsol = G*Ms/rs^2*rsnorm
    zp = zeros(6)
    zp[1:3] = xp
    zp[4:6] = Fg+Fluna+Fsol
    return zp
end

t = 0 
z = z0

Nt = 1000

println("z0 = " ,z0)
println("zp = " ,zpunto(t,z))

z = zeros(6,Nt)

z[:,1] = z0

#Euler
for i in 2:Nt
    zp = zpunto(t, z[:,i-1])
    z[:,i] = z[:, i-1] + zp*dt
    println("z_i = ", z[:,i])
end
function 
#Runge-kutta 4to orden (Esto no funciona)

RK4(f::Array{Function,1},t0::Float64,x::Array{Float64,1},h::Float64)
    d=length(f)

    hk1=zeros(x)
    hk2=zeros(x)
    hk3=zeros(x)
    hk4=zeros(x)

    for ii in 1:d
        hk1[ii]=h*f[ii](t0,x)
    end
    for ii in 1:d
        hk2[ii]=h*f[ii](t0+h/2,x+hk1/2)
    end
    for ii in 1:d
        hk3[ii]=h*f[ii](t0+h/2,x+hk2/2)
    end
    for ii in 1:d
        hk4[ii]=h*f[ii](t0+h,x+hk3)
    end

    return t0+h,x+(hk1+2*hk2+2*hk3+hk4)/6
end
function Solver(f::Array{Function,1},Method::Function,t0::Float64,
        x0::Array{Float64,1},h::Float64,N::Int64)
    d=length(f)
    ts=zeros(Float64,N+1)
    xs=zeros(Float64,d,N+1)

    ts[1]=t0
    xs[:,1]=x0

    for i in 2:(N+1)
        ts[i],xs[:,i]=Method(f,ts[i-1],xs[:,i-1],h)
    end

    return ts,xs
end
tRK4,xRK4=Solver(f,RK4,0,z0,dt,Nt)
println(tRK4,xRK4)
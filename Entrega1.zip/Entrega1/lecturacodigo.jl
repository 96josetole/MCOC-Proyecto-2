using LightXML

xdoc = parse_file("S1B_OPER_AUX_POEORB_OPOD_20180904T110615_V20180814T225942_20180816T005942.EOF")

xroot = root(xdoc)

println(name(xroot))

for c in child_nodes(xroot)
	println(nodetype(c))
	if is_elementnode(c)
		e = XMLElement(c)
		println(name(e))
	end
end

#ces = collect(child_elements(xroot))
#@assert lenght(ces)==2

ces = get_elements_by_tagname(xroot,"List_of_OSVs")
ces = xroot["List_of_OSVs"]
e1 = ces[1]
println[e1]

t = find_element(ces,"X")
a = content(t)
println(a)